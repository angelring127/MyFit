package com.example.angel.myfit.basichistoryapi.fitChart;

/**
 * Created by YOUNSANGHO on 2016-05-22.
 */
public enum AnimationMode {
    LINEAR,
    OVERDRAW
}

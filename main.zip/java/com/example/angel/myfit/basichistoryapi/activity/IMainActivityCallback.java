package com.example.angel.myfit.basichistoryapi.activity;

/**
 * Created by chris.black on 5/2/15.
 */
public interface IMainActivityCallback {
    public void onSectionAttached(int number);
}

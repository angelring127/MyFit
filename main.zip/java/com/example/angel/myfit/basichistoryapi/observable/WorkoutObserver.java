package com.example.angel.myfit.basichistoryapi.observable;

import com.example.angel.myfit.basichistoryapi.model.WorkoutReport;

import rx.Observer;

/**
 * Created by chris.black on 5/4/15.
 */
public class WorkoutObserver implements Observer<WorkoutReport> {

    @Override
    public void onNext(WorkoutReport value) {

    }

    @Override
    public void onCompleted() {

    }

    @Override
    public void onError(Throwable e) {

    }
}
